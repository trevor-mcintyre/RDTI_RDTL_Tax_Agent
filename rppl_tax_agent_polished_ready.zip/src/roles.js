
export const Roles = {
  ADMIN: 'admin',
  ACCOUNTANT: 'accountant',
  REVIEWER: 'reviewer',
  AUDITOR: 'auditor',
};
