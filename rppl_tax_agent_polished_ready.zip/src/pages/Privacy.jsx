
import React from "react";
export default function PrivacyPage() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Privacy Policy</h1>
      <p>This is the placeholder privacy policy.</p>
    </div>
  );
}
