
import React from "react";
export default function TermsPage() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Terms of Service</h1>
      <p>These are the placeholder terms of service.</p>
    </div>
  );
}
