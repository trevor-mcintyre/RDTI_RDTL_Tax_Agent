
// cli/index.js
console.log("RPPL CLI Tool (Preview)");

const args = process.argv.slice(2);
if (args.includes("--export")) {
  console.log("Simulating export of claims...");
  // Extend to hit mock API endpoint
}
